package ca.umontreal.iro.hackathon.loderunner;

public enum Event {
    MOVE, DIG;
}