package sunrise.astar;

public class Edge {
	
	NodeAStar nFin;
	
	int valuePath;
	

	public Edge(NodeAStar nFin,int valuePath) {
		
		this.nFin = nFin;
		
		this.valuePath = valuePath;
	}
	
	public int getValuePath() {
		return valuePath;
	}

	public NodeAStar getnFin() {
		return nFin;
	}

}
