package ca.umontreal.iro.hackathon.loderunner;

public class NodeRunnerAI {

    public static void main(String[] args) {
        Runner road = new Runner();

        road.run();
    }
}
